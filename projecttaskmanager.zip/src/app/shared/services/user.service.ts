import { Injectable } from '@angular/core';
import { ApiService } from 'src/app/shared/api.service';
import { Observable } from 'rxjs';
import { User } from 'src/app/models/user';
import { HttpParams } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private apiService: ApiService) { }
  
  create(user: User): Observable<any> {
    return this.apiService.post("Users", user);
  }

  getAll(): Observable<any> {
    return this.apiService.get("Users");
  }

  update(user:User): Observable<any> {
    return this.apiService.put("Users",user);
  }
  deleteUser(user_id: number) {    
   return this.apiService.delete("USers",new HttpParams().set("id",user_id.toString()));
  }
  searchUser(searchValue:string){
    return this.apiService.get("Users/SearchUsers",new HttpParams().set("searchText",searchValue));
  }
}
