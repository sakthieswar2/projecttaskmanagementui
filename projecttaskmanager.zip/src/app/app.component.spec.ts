import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppComponent } from './app.component';
import { Routes, RouterModule } from '@angular/router';
import { AdduserComponent } from './user/adduser/adduser.component';
import { UserComponent } from './user/user/user.component';
import { AddprojectComponent } from './project/addproject/addproject.component';
import { ProjectComponent } from './project/project/project.component';
import { AddtaskComponent } from './task/addtask/addtask.component';
import { TaskComponent } from './task/task/task.component';
import { PopupsComponent } from './modal/popups/popups.component';
import { UiModule } from './ui/ui.module';
import { FormsModule,ReactiveFormsModule,FormBuilder, FormGroup, Validators,FormControl  } from '@angular/forms';



describe('AppComponent', () => {
  const routes: Routes = [
    { path: 'User', component: UserComponent },
    { path: 'Project', component: ProjectComponent },
    { path: 'AddTask', component: AddtaskComponent },
    { path: 'updatetask/:id', component: AddtaskComponent },
    { path: 'Task', component: TaskComponent }  ,
    { path: 'viewtask/:id', component: TaskComponent }
  ];
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        RouterModule.forRoot(routes),
        UiModule,FormsModule,ReactiveFormsModule
      ],
      declarations: [
        AppComponent,
        AdduserComponent,
        UserComponent,
        AddprojectComponent,
        ProjectComponent,
        AddtaskComponent,
        TaskComponent,
        PopupsComponent,
      ],
    }).compileComponents();
  }));

  // beforeEach(() => {
  //   fixture = TestBed.createComponent(AddtaskComponent);
  //   component = fixture.componentInstance;
  //   fixture.detectChanges();
  // });

  it('should create the app', async(() => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  }));
  it(`should have as title 'app'`, async(() => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app.title).toEqual('ProjectManager');
  }));
});
