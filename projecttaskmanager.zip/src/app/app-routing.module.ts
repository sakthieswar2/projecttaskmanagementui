import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserComponent } from 'src/app/user/user/user.component';
import { ProjectComponent } from 'src/app/project/project/project.component';
import { TaskComponent } from 'src/app/task/task/task.component';
import { AddtaskComponent } from 'src/app/task/addtask/addtask.component';

const routes: Routes = [
  { path: 'User', component: UserComponent },
  { path: 'Project', component: ProjectComponent },
  { path: 'AddTask', component: AddtaskComponent },
  { path: 'updatetask/:id', component: AddtaskComponent },
  { path: 'Task', component: TaskComponent }  ,
  { path: 'viewtask/:id', component: TaskComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
