import { Component, OnInit, TemplateRef } from '@angular/core';
import { BsModalService } from 'ngx-bootstrap';
import { TaskService } from 'src/app/shared/services/task.service';
import { ProjectService } from 'src/app/shared/services/project.service';
import { ActivatedRoute } from '@angular/router';
import * as _ from 'lodash';

@Component({
  selector: 'app-task',
  templateUrl: './task.component.html',
  styleUrls: ['./task.component.css']
})
export class TaskComponent implements OnInit {
  tasks;
  sortedBy;
  sortedOrder;
  bsModalRef;
  project = null;

  constructor(private taskService: TaskService,
    private projectService: ProjectService,
    private modalService: BsModalService,
    private route: ActivatedRoute) { }

  ngOnInit() {
    var id = this.route.snapshot.params['id'];
    if (id != null) {
      this.projectService.getById(id).subscribe(data => {
        this.project = { id: data.project_id, value: data.project_title };
        if(this.project != null)
          this.getTaskbyProject(id);
        else
        {
          alert('Project id is not found in the system, please try again with valid project id.');
        }
      });
    }
  }

  getTasks() {
    this.taskService.getAll()
      .subscribe(data => { 
        console.log(data);       
        this.tasks = data;
      });
  }
  openModal(template: TemplateRef<any>) {
    this.bsModalRef = this.modalService.show(template);
  }
getTaskbyProject(project_id)
{
  this.taskService.getByProjectId(project_id)
      .subscribe(data => { 
        console.log(data);       
        this.tasks = data;
      });
}
  updateSearchProject(lookup) {
    this.bsModalRef.hide();
    this.project = { project_id: lookup.id, project_title: lookup.value };
    this.getTaskbyProject(this.project.project_id);
    //this.getTasks(lookup.id);
  }



  sortTasks(sortBy: string, sortOrder) {
    if (!(sortOrder != null && this.sortedBy != sortBy)) {
      sortOrder = this.sortedBy != sortBy || this.sortedOrder == "desc" ? "asc" : "desc";
    }
    this.tasks = _.orderBy(this.tasks, [sortBy], [sortOrder]);
    this.sortedBy = sortBy;
    this.sortedOrder = sortOrder;
  }

  endTask(taskId) {
    this.taskService.endTask(taskId)
      .subscribe( data=> {
        alert('Task ended successfully');
        this.getTaskbyProject(this.project.project_id);
      });
  }

  closeModal() {
    this.bsModalRef.hide();
  }
}
