import { async, ComponentFixture, TestBed, fakeAsync, inject } from '@angular/core/testing';
import { BsModalService, ModalModule } from 'ngx-bootstrap';
import { TaskService } from 'src/app/shared/services/task.service';
import { ProjectService } from 'src/app/shared/services/project.service';
import { ActivatedRoute } from '@angular/router';
import { TaskComponent } from './task.component';
import { PopupsComponent } from 'src/app/modal/popups/popups.component';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { ApiService } from 'src/app/shared/api.service';
import { TASKS } from './../../mockdata/mockfile';

describe('TaskComponent', () => {
  let component: TaskComponent;
  let fixture: ComponentFixture<TaskComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ReactiveFormsModule, HttpClientModule, ModalModule.forRoot(), RouterTestingModule],
      declarations: [ TaskComponent, PopupsComponent ],
      providers: [TaskService, ProjectService, ApiService]
    })
    .compileComponents();

    spyOn(ApiService.prototype, 'put').and.returnValue(of({ status: 204 }));
    spyOn(ApiService.prototype, 'get').and.returnValue(of(TASKS));
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TaskComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });  
});
