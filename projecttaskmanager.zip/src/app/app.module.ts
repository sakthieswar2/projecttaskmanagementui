import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule,ReactiveFormsModule  } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { BsModalService } from 'ngx-bootstrap/modal';
import { ModalModule } from 'ngx-bootstrap/modal';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UiModule } from './ui/ui.module';
import { AdduserComponent } from './user/adduser/adduser.component';
import { UserComponent } from './user/user/user.component';
import { AddprojectComponent } from './project/addproject/addproject.component';
import { ProjectComponent } from './project/project/project.component';
import { AddtaskComponent } from './task/addtask/addtask.component';
import { TaskComponent } from './task/task/task.component';
import { PopupsComponent } from './modal/popups/popups.component';
import { FilterPipe } from 'src/app/shared/pipes/filter.pipe';

@NgModule({
  declarations: [
    AppComponent,
    AdduserComponent,
    UserComponent,
    AddprojectComponent,
    ProjectComponent,
    AddtaskComponent,
    TaskComponent,
    PopupsComponent,
    FilterPipe
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    UiModule,
    ModalModule.forRoot()
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
