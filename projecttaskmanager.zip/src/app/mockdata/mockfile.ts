import { Task } from 'src/app/models/task';
import { Project } from 'src/app/models/project';
import { User } from 'src/app/models/user';



export const TASKS: Task[] = [
    {
        task_id: 1,
        taskName: 'demo',
        priority: 5,
        startdate: new Date(2018, 12, 12),
        enddate: new Date(2018, 12, 12),
        isParentTask: false,
        status: 0,
        
        parent_id: 1,
        parentTask: 'parent task',
        project_id: 1,
        project_title:'Test project',
        task_user:1
    },
    {
        task_id: 2,
        taskName: 'demo',
        priority: 5,
        startdate: new Date(2018, 12, 12),
        enddate: new Date(2018, 12, 12),
        isParentTask: false,
        status: 0,
        
        parent_id: 1,
        parentTask: 'parent task',
        project_id: 1,
        project_title:'Test project',
        task_user:1
    }];

export const PROJECTS: Project[] = [
    {
        project_id: 1,
        project_title: "Test project",
        priority: 10,
        startdate: new Date(2018, 1, 1),
        enddate: new Date(2018, 1, 1),
        manager_id: 1,
        manager_name: 'test',
        manager: null
    },
    {
        project_id: 2,
        project_title: "Test project 2",
        priority: 10,
        startdate: new Date(2018, 2, 1),
        enddate: new Date(2018, 3, 1),
        manager_id: 2,
        manager_name: 'test user',
        manager: null
    }
];

export const USERS: User[] = [
    {
        user_id: 1,
        first_name: "first name",
        last_name: "last name",
        employee_id: "12345"
    },
    {
        user_id: 2,
        first_name: "first name1",
        last_name: "last name1",
        employee_id: "456789"
    }];