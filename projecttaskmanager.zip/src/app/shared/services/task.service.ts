import { Injectable } from '@angular/core';
import { HttpParams } from '@angular/common/http';

import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { ApiService } from 'src/app/shared/api.service';
import { Task } from 'src/app/models/task';

@Injectable({
  providedIn: 'root'
})
export class TaskService {

  constructor(private apiService: ApiService) { }

  create(task: Task): Observable<any> {
    return this.apiService.post("Tasks", task);
  }

  update(task: Task): Observable<any> {
    return this.apiService.put("Tasks", task);
  }

  getAll(): Observable<any> {
    return this.apiService.get("Tasks");
  }

  getParentTasks(): Observable<any> {
    return this.apiService.get("Tasks/GetParentTasks");
  }

  getByProjectId(projectId): Observable<any> {
    return this.apiService.get("Tasks/GetTaskByProject/" + projectId);
  }

  getById(taskId: number): Observable<any> {
    return this.apiService.get("Tasks/GetTask/" + taskId);
  }
  endTask(taskId: number): Observable<any> {
    return this.apiService.put("Tasks/PutEndTask/" + taskId);
  }
}
