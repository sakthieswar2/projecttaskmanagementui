import { Project } from "./project";

export interface Task {
    task_id: number;
    taskName: string;
    priority: number;
    startdate?: Date;
    enddate?: Date;
    isParentTask: boolean;    
    status: boolean;
    
    parent_id?: number;
    parentTask: Task;
    project_id: number;
    project_title:string;
    project: Project;
    task_user:number;
}
