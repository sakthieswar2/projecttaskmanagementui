import { Injectable } from '@angular/core';
import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { ApiService } from 'src/app/shared/api.service';
import { Project } from 'src/app/models/project';
import { Observable } from 'rxjs';
import { ParentTask } from 'src/app/models/parenttask';
import { Task } from 'src/app/models/task';

@Injectable({
  providedIn: 'root'
})
export class ParenttaskService {

  constructor(private apiService: ApiService) { }
  create(task: ParentTask): Observable<any> {
    return this.apiService.post("Parent_Task", task);
  }
  getAll(): Observable<any> {
    return this.apiService.get("Parent_Task");
  }
}
