import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { UserService } from 'src/app/shared/services/user.service';
import { ProjectService } from 'src/app/shared/services/project.service';
import * as _ from 'lodash';
import { ParenttaskService } from 'src/app/shared/services/parenttask.service';
import { BsModalService } from 'ngx-bootstrap';

@Component({
  selector: 'app-popups',
  templateUrl: './popups.component.html',
  styleUrls: ['./popups.component.css']
})
export class PopupsComponent implements OnInit {
  lookups: { id: number, value: string }[] = [];
  allLookups;
  closeBtnName = "Close";

  @Output()
  closeClick = new EventEmitter();

  @Input()
  lookupFor: string;

  @Output()
  lookupSelect = new EventEmitter();
  constructor(private userService: UserService,
            private projectService: ProjectService,
            private parentTaskService: ParenttaskService
          ) { }

  ngOnInit() {
    switch (this.lookupFor) {

      case "Project":
        this.projectService.getAll()
          .subscribe(data => {
            _.forEach(data, (m) => {
              this.lookups.push({ id: m.project_id, value: m.project_title });
            });
          });
        break;

      case "User":
        this.userService.getAll()
          .subscribe(data => {
            _.forEach(data, (m) => {
              this.lookups.push({ id: m.user_id, value: m.first_name });
            });
          });
        break;

      case "ParentTask":
        this.parentTaskService.getAll()
          .subscribe(data => {
            _.forEach(data, (m) => {
              this.lookups.push({ id: m.task_id, value: m.taskName });
            });
          });
        break;
    }

   
  }
  searchLookup(searchText) {
    this.lookups = _.filter(this.allLookups,
      (m) => m.value.toLowerCase().indexOf(searchText.toLowerCase()) !== -1)
  }

  selectLookup(lookup) {
    this.lookupSelect.emit(lookup);
  }

  closeModal() {
    //this.closeClick.emit();
  }

}
