export const environment = {
  production: true,
  api_url: "http://localhost:53849/api/"
};