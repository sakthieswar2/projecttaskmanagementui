import { Injectable } from '@angular/core';
import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { ApiService } from 'src/app/shared/api.service';
import { Project } from 'src/app/models/project';
import { Observable } from 'rxjs';
import * as _ from 'lodash';
import { HttpParams } from '@angular/common/http';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ProjectService {

  constructor(private apiService: ApiService) { }
  
  create(user: Project): Observable<any> {
    return this.apiService.post("Projects", user);
  }

  getAll(): Observable<any> {
    return this.apiService.get("Projects");
  }

  update(Project: Project): Observable<any> {
    return this.apiService.put("Projects", Project);
  }
  getById(id: number): Observable<any> {
    return this.apiService.get("Projects/GetProject", new HttpParams().set("id", id.toString()))
      .pipe(map(Project => this.mapProject(Project)));
  }

  delete(id: number) {
    return this.apiService.delete("Projects", new HttpParams().set("id", id.toString()));
  }
  private mapProject(project): Project {
    project.tasksCompleted = _.filter(project.tasks, (m) => m.isCompleted).length;
    return project;
  }
}
