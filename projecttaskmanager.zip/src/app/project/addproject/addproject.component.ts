import { Component, OnInit,Output,Input,EventEmitter } from '@angular/core';
import { FormBuilder,FormGroup, Validators, FormControl } from '@angular/forms';
import { Project } from 'src/app/models/project';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal'
import { TemplateRef } from '@angular/core';
import { ProjectService } from 'src/app/shared/services/project.service';
import * as moment from 'moment';

@Component({
  selector: 'app-addproject',
  templateUrl: './addproject.component.html',
  styleUrls: ['./addproject.component.css']
})
export class AddprojectComponent implements OnInit {
  
  
  projectForm: any;  
  isUpdate = false;
  submitted = false;
  _project: Project;
  modalRef: BsModalRef;

  @Output()
  projectSubmit = new EventEmitter();

  @Input()
  set project(project) {

    if (project != null) {
      this.isUpdate = true;
      var isChecked = project.startdate != null;

      this.projectForm.patchValue({
        ...project,
        startdate: moment(project.startdate).format("YYYY-MM-DD"),
        enddate: moment(project.enddate).format("YYYY-MM-DD"),
        setDuration: isChecked,
        priority: project.priority,
        manager_id: project.manager_id,
        manager_name:project.manager_name
        //manager: project.manager != null ? project.manager.first_name : null
      });

      this.setDatesState(isChecked);
    }
  }

  constructor(private projectService:ProjectService
    ,private modalService: BsModalService
  ,private fb: FormBuilder) { }

  ngOnInit() {
    this.projectForm = this.fb.group({
      project_id: 0,
      project_title: [null, Validators.required],
      priority: 0,
      setDuration: false,
      startdate: [{ value: null, disabled: true }],
      enddate: [{ value: null, disabled: true }],
      manager_id: null,
      manager_name:null,
      manager: ''
    });
  }


    onSubmit() {
      this.submitted = true;
  
      if (this.projectForm.invalid) {
        return;
      }
  
      if (!this.isUpdate) {
        this.projectService.create(this.projectForm.value)
          .subscribe(() => {
            this.resetForm();
            this.projectSubmit.emit();
            alert("Project created successfully");
          });
      }
      else {
        this.projectService.update(this.projectForm.value)
          .subscribe(() => {
            this.resetForm();
            this.projectSubmit.emit();
            this.isUpdate = false;
            alert("Project updated successfully");
          });
      }
    }
    resetForm() {
      this.submitted = false;
      this.projectForm.priority= 0;
      this.projectForm.reset({ });
      this.setDatesState(false);
  }

  cancelEdit() {
    this.isUpdate = false;
    this.resetForm();
}
openModal(template: TemplateRef<any>) {
  this.modalRef = this.modalService.show(template);
}
updateManager(lookup) {
  this.modalRef.hide();
  this.projectForm.patchValue({ manager_id: lookup.id, manager_name: lookup.value });
}
setStartEndDates(isChecked) {

  this.projectForm.patchValue({
    startdate: isChecked ? moment().format("YYYY-MM-DD") : null,
    enddate: isChecked ? moment().add({ days: 1 }).format("YYYY-MM-DD") : null
  });

  this.setDatesState(isChecked);
}

setDatesState(isChecked) {
  if (isChecked) {
    this.projectForm.controls["startdate"].enable();
    this.projectForm.controls["enddate"].enable();

  }
  else {
    this.projectForm.controls["startdate"].disable();
    this.projectForm.controls["enddate"].disable();
  }
}

}
