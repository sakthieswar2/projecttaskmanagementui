import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule,ReactiveFormsModule,FormBuilder, FormGroup, Validators,FormControl  } from '@angular/forms';
import { Project } from 'src/app/models/project';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal'
import { TemplateRef } from '@angular/core';
import { ApiService } from 'src/app/shared/api.service';
import { ProjectService } from 'src/app/shared/services/project.service';
import * as moment from 'moment';

import { AddprojectComponent } from './addproject.component';
import { HttpClientModule } from '@angular/common/http';
import { ModalModule } from 'ngx-bootstrap';
import { PopupsComponent } from 'src/app/modal/popups/popups.component';

describe('AddprojectComponent', () => {
  let component: AddprojectComponent;
  let fixture: ComponentFixture<AddprojectComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ReactiveFormsModule, HttpClientModule, ModalModule.forRoot()],
      declarations: [AddprojectComponent, PopupsComponent],
      providers: [ProjectService, ApiService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddprojectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
