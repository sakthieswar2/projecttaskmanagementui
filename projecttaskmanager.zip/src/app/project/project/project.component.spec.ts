import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule,ReactiveFormsModule,FormBuilder, FormGroup, Validators,FormControl  } from '@angular/forms';
import { Project } from 'src/app/models/project';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal'
import { TemplateRef } from '@angular/core';
import { ApiService } from 'src/app/shared/api.service';
import { ProjectService } from 'src/app/shared/services/project.service';
import { HttpClientModule } from '@angular/common/http';
import { ModalModule } from 'ngx-bootstrap';
import { PopupsComponent } from 'src/app/modal/popups/popups.component';
import { ProjectComponent } from './project.component';
import { AddprojectComponent } from 'src/app/project/addproject/addproject.component';

describe('ProjectComponent', () => {
  let component: ProjectComponent;
  let fixture: ComponentFixture<ProjectComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ReactiveFormsModule, HttpClientModule, ModalModule.forRoot()],
      declarations: [ProjectComponent, PopupsComponent,AddprojectComponent],
      providers: [ProjectService, ApiService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProjectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
