// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { UserComponent } from './user.component';
// import { FormBuilder, FormGroup, Validators,FormControl,ReactiveFormsModule } from '@angular/forms';
// import { HttpClientModule } from '@angular/common/http';
// import { AdduserComponent } from 'src/app/user/adduser/adduser.component';
// import { UserService } from 'src/app/shared/services/user.service';
// import { RouterTestingModule } from '@angular/router/testing';
// import { ApiService } from 'src/app/shared/api.service';
// import * as _ from 'lodash';

// describe('UserComponent', () => {
//   let component: UserComponent;
//   let fixture: ComponentFixture<UserComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       imports: [ReactiveFormsModule, HttpClientModule,FormGroup, Validators,FormControl,ReactiveFormsModule],
//       declarations: [ FormGroup,UserComponent, AdduserComponent ],
//       providers: [UserService, ApiService]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(UserComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
