import { Project } from "./project";

export interface ParentTask {
    task_id: number;
    taskName: string;
    project_id: number;
}