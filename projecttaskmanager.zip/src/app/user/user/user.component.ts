import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/models/user';
import { UserService } from 'src/app/shared/services/user.service';
import * as _ from 'lodash';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  users: User[];
  filterdUsers: User[];
  user;
  sortedBy;
  sortedOrder;
  
  _listFilter = '';
  get listFilter(): string {
    return this._listFilter;
  }
  set listFilter(value: string) {
    this._listFilter = value;
    this.filterdUsers = this.listFilter ? this.performFilter(this.listFilter) : this.users;
  }

  constructor(private userService: UserService) { }

  ngOnInit() {
    this.getUsers();
  }

  getUsers() {
    this.userService.getAll()
      .subscribe(data => {
        this.filterdUsers = data;
      });
  }
  editUser(_user: User){
    this.user = _user;
  }
  deleteUser(user_id: number){
    this.userService.deleteUser(user_id)
      .subscribe(() => {
        this.getUsers();
        alert("User deleted successfully");
      });
  }
  searchUsers(filterBy)
  {    
    filterBy = filterBy.toLocaleLowerCase();
    // alert(filterBy);
    // this.filterdUsers = this.users.filter((user: User) =>
    //   user.first_name.toLocaleLowerCase().indexOf(filterBy) != -1);
    // this.filterdUsers = this.users;
    // console.log(this.filterdUsers);
    this.userService.searchUser(filterBy)
    .subscribe(data => {
      this.users = data;
    });
  }
  sortUsers(sortBy: string) {
    var sortOrder = this.sortedBy != sortBy || this.sortedOrder == "desc" ? "asc" : "desc";
    this.users = _.orderBy(this.users, [sortBy], [sortOrder]);
    this.sortedBy = sortBy;
    this.sortedOrder = sortOrder;
  }

  performFilter(filterBy: string): User[] {
    filterBy = filterBy.toLocaleLowerCase();
    return this.users.filter((user: User) =>
      user.first_name.toLocaleLowerCase().indexOf(filterBy) !== -1);
  }

}
