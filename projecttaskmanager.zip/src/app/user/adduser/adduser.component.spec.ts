import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Component, OnInit,Output,EventEmitter,Input } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { FormBuilder, FormGroup, Validators,FormControl,ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { User } from 'src/app/models/user';
import { ApiService } from 'src/app/shared/api.service';
import { UserService } from 'src/app/shared/services/user.service';
import { RouterTestingModule } from '@angular/router/testing';
import { AdduserComponent } from './adduser.component';

describe('AdduserComponent', () => {
  let component: AdduserComponent;
  let fixture: ComponentFixture<AdduserComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ReactiveFormsModule, HttpClientModule],
      declarations: [AdduserComponent],
      providers: [UserService, ApiService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdduserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('form invalid when empty', () => {
    expect(component.userForm.valid).toBeFalsy();
  });

  it('form valid when submitted', () => {
    expect(component.userForm.valid).toBeFalsy();
    component.userForm.controls['employee_id'].setValue("12345");
    component.userForm.controls['first_name'].setValue("Test");
    component.userForm.controls['last_name'].setValue("user");
    expect(component.userForm.valid).toBeTruthy();
  });

  it("should reset form", () => {
    component.userForm.patchValue({ first_name: "123" });
    component.resetForm();
    expect(component.userForm.controls["first_name"].value).toBeNull();
  })
});
