import { Component, OnInit, TemplateRef } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { TaskService } from 'src/app/shared/services/task.service';
import { Router, ActivatedRoute } from '@angular/router';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal'
import { switchMap } from 'rxjs/operators';
import * as moment from 'moment';
import { Task } from 'src/app/models/task';
import { ProjectService } from 'src/app/shared/services/project.service';
import { ParentTask } from 'src/app/models/parenttask';
import { ParenttaskService } from 'src/app/shared/services/parenttask.service';

@Component({
  selector: 'app-addtask',
  templateUrl: './addtask.component.html',
  styleUrls: ['./addtask.component.css']
})
export class AddtaskComponent implements OnInit {
  taskForm;
  submitted = false;
  isUpdate = false;
  bsModalRef;
  tasks:Task[];
  parentTask:ParentTask;
  


  get projectId() {
    return this.taskForm.get('project_id').value
  }
  constructor(private fb: FormBuilder,
    private taskService: TaskService,
    private projectService: ProjectService,
    private parentService: ParenttaskService,
    private router: Router,
    private route: ActivatedRoute,
    private modalService: BsModalService) { }

  ngOnInit() {
    this.taskForm = this.fb.group({
      task_id: 0,
      project_id: [null, Validators.required],
      project_title: null,
      taskName: [null, Validators.required],
      priority: [0],
      isParentTask: false,
      parent_id: null,
      parentTaskTitle: null,
      startdate: null,
      enddate: null,
      userId: null,
      userName: null,
      task_user:null,
      status:0
    });

    
    if (this.route.snapshot.params['id'] != null) {
      this.isUpdate = true;
      this.route.params
        .pipe(switchMap(params =>
          this.taskService.getById(this.route.snapshot.params['id'])
        ))
        .subscribe(
          task => 
          {
            if(task != null){
              this.patchTaskForm(task)
          }
          });
    }
  }
  getTasks() {
    this.taskService.getAll()
      .subscribe(data => {        
        this.tasks = data;
      });
  }
  patchTaskForm(task) {
    this.taskForm.patchValue({
      ...task,
      startdate: task.startdate != null ? moment(task.startDate).format("YYYY-MM-DD") : null,
      enddate: task.enddate != null ? moment(task.endDate).format("YYYY-MM-DD") : null,
      project_id: task.project_id != null ? task.project_id : null,
      project_title: task.project_title != null ? task.project_title : null,
      priority: task.priority,
      userId: task.task_user_id != null ? task.task_user_id : null,
      userName: task.task_user != null ? task.task_user : null,
      parent_id: task.parent_id != null ? task.parent_id : null,
      parentTaskTitle: task.parent_task_name != null ? task.parent_task_name : null,
      task_user: task.task_user_id
    });
  }



  addTask() {
    console.log(this.taskForm.value);
    this.submitted = true;
    if (this.taskForm.invalid) {
      return;
    }

    if (!this.isUpdate) {
      if(this.taskForm.value['isParentTask'])
      {
        this.parentTask = { task_id:0, taskName: this.taskForm.value['taskName'], project_id: this.projectId};
        //alert(this.parentTask.taskName + '  orih id: ' + this.parentTask.project_id);
        this.parentService.create(this.parentTask)
            .subscribe(() => {
              alert('Parent task created successfully.');
            })
      }
      else
      {
        
      this.taskService.create(this.taskForm.value)
        .subscribe(() => {
          alert("Task created successfully");
          //this.router.navigate(["/viewtask", this.projectId]);
        });
      }
    }
    else {
      this.taskService.update(this.taskForm.value)
        .subscribe(() => {
          alert("Task updated successfully");
          this.router.navigate(["/viewtask", this.projectId]);
        });
    }
  }

  endtask()
  {
    this.taskForm.value.status = 1;
    this.taskService.update(this.taskForm.value)
        .subscribe(() => {
          alert("Task ended successfully");
          this.router.navigate(["/viewtask", this.projectId]);
        });
  }

  disableTaskFields(isChecked) {
    if (!isChecked) {
      this.taskForm.controls["priority"].enable();
      this.taskForm.controls["startdate"].enable();
      this.taskForm.controls["enddate"].enable();
    }
    else {
      this.taskForm.patchValue({
        userId: null, userName: null,
        parent_id: null, parentTaskTitle: null
      });
      this.taskForm.controls["priority"].disable();
      this.taskForm.controls["startdate"].disable();
      this.taskForm.controls["enddate"].disable();
    }
  }

  resetForm() {
    this.submitted = false;
  }

  openModal(template: TemplateRef<any>) {
    this.bsModalRef = this.modalService.show(template);
  }

  updateUserSelected(lookup) {
    this.closeModal();
    this.taskForm.patchValue({ task_user: lookup.id, userName: lookup.value });
  }

  updateParentTaskSelected(lookup) {
    this.closeModal();
    this.taskForm.patchValue({ parent_id: lookup.id, parentTaskTitle: lookup.value });
  }

  updateProjectSelected(lookup) {
    this.closeModal();
    this.taskForm.patchValue({ project_id: lookup.id, project_title: lookup.value });
  }

  removeModal(){
    this.closeModal();
  }
  closeModal() {
    this.bsModalRef.hide();
  }
  

}
