import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { BsModalService } from 'ngx-bootstrap/modal';
import { ModalModule } from 'ngx-bootstrap/modal';
import { FormBuilder, Validators, ReactiveFormsModule } from '@angular/forms';
import { TaskService } from 'src/app/shared/services/task.service';
import { Router, ActivatedRoute } from '@angular/router';
import { switchMap } from 'rxjs/operators';
import * as moment from 'moment';
import { Task } from 'src/app/models/task';
import { ProjectService } from 'src/app/shared/services/project.service';
import { ParentTask } from 'src/app/models/parenttask';
import { ParenttaskService } from 'src/app/shared/services/parenttask.service';
import { AddtaskComponent } from './addtask.component';
import { HttpClientModule } from '@angular/common/http';
import { PopupsComponent } from 'src/app/modal/popups/popups.component';
import { RouterTestingModule } from '@angular/router/testing';
import { ApiService } from 'src/app/shared/api.service';


describe('AddtaskComponent', () => {
  let component: AddtaskComponent;
  let fixture: ComponentFixture<AddtaskComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ReactiveFormsModule, HttpClientModule, ModalModule.forRoot(), RouterTestingModule],
      declarations: [ AddtaskComponent, PopupsComponent ],
      providers: [TaskService, ProjectService, ApiService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddtaskComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  
  it('form invalid when empty', () => {
    expect(component.taskForm.valid).toBeFalsy();
  });


  it('form valid when submitted', () => {
    expect(component.taskForm.valid).toBeFalsy();
    component.taskForm.controls['project_id'].setValue("1");
    component.taskForm.controls['taskName'].setValue("test task");
    component.taskForm.controls['startdate'].setValue("2018-01-01");
    component.taskForm.controls['enddate'].setValue("2018-01-01");
    component.taskForm.controls['parent_id'].setValue("1");
    expect(component.taskForm.valid).toBeTruthy();
  });
});

