export class TaskSearch
{
    Id: number;
    Task: string;
    PriorityFrom: number;
    PriorityTo: number;
    ParentTask: number;
    StartDate: Date;
    EndDate: Date;
}