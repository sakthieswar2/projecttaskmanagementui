import { Component, OnInit,Output,EventEmitter,Input } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { FormBuilder, FormGroup, Validators,FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { User } from 'src/app/models/user';
import { ApiService } from 'src/app/shared/api.service';
import { UserService } from 'src/app/shared/services/user.service';
import { IfStmt } from '@angular/compiler';

@Component({
  selector: 'app-adduser',
  templateUrl: './adduser.component.html',
  styleUrls: ['./adduser.component.css'],
  providers: []
})
export class AdduserComponent implements OnInit {

  
  // userForm = new FormGroup({
  //   //user_id: new FormControl(0,null),
  //   first_name: new FormControl('', Validators.required),
  //   last_name: new FormControl('',  Validators.required),
  //   employee_id:new FormControl('',  Validators.required)
  // });
  userForm;
  isUpdate = false;
  submitted = false;

  @Output()
  userSubmit = new EventEmitter();

  @Input()
  set user(user) {
      if (user != null) {
          this.isUpdate = true;
          this.userForm.patchValue(user);
      }
  }

  myUser: User;
  constructor(private _service: UserService,
    private fb: FormBuilder) {       
}

    ngOnInit() {    
      this.userForm = this.fb.group({
        user_id: 0,
        first_name: [null, Validators.required],
        last_name: [null, Validators.required],
        employee_id: [null, Validators.required]
    });  
      }

    onSubmit() {      
      this.submitted = true;     

if (this.userForm.invalid) {
            return;
        }
        if(!this.isUpdate)
        {
        //this.myUser = this.userForm.value;
        //lert(this.myUser.user_id);
            this._service.create(this.userForm.value).subscribe(() => {
              this.resetForm();
              this.userSubmit.emit();
              alert("User created successfully");
          });
        }
        else
        {
          this._service.update(this.userForm.value)
                .subscribe(() => {
                    this.resetForm();
                    this.userSubmit.emit();
                    this.isUpdate = false;
                    alert("User updated successfully");
                });
        }
    }
    resetForm() {
      this.submitted = false;
      this.userForm.reset({ });
  }

  cancelEdit() {
    this.isUpdate = false;
    this.resetForm();
}

}
