import { Task } from "./task";
import { User } from "./user";

export interface Project {
    project_id: number;
    project_title: string;
    priority: number;
    startdate: Date;
    enddate: Date; 
    
    manager_name: string;
    manager_id: number;
    manager: User;   
}